const APP_URL = "http://localhost:3000/"
const tbody_pacients = document.getElementById("tbody_pacients");

const addButton = document.getElementById("addButton");
document.getElementById('upload_pacients').addEventListener('click', async () => {
    try {
      const res = await fetch(APP_URL +'upload-pacients', {
        method: 'POST'
      });
      const data = await res.json();
      alert(`${data.message}`);
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });

  (async function index() {
    const res = await fetch (APP_URL+"pacients");
    const data = await res.json();
    console.log("GET:", data);
    tbody_pacients.innerHTML = "";
    data.forEach(paciente => {
      tbody_pacients.innerHTML += `
      <tr>
        <td>${paciente.id_pacient}</td>
        <td>${paciente.name}</td>
        <td>${paciente.email}</td>
        <td>
             <button class="btn btn-sm btn-warning" onclick="updateData(${paciente.id_pacient})">update</button>
            <button class="btn btn-sm btn-danger" onclick="deleteData(${paciente.id_pacient})">Eliminar</button>

        </td>
    </tr>
      `
      
    });
    
  })()
  
async function store() {
  
  try {
  const pacient_name = document.getElementById("pacient_name").value.trim();
  const pacient_email = document.getElementById("pacient_email").value.trim();

  if (!pacient_name || !pacient_email) {
    alert("Todos los campos son obligatorios");
    return;
  }


  const resUsers = await fetch(APP_URL + "pacients");
  const users = await resUsers.json();

  const existe = users.some(user => user.email.toLowerCase() === pacient_email.toLowerCase());
  if (existe) {
    alert("El email ya está registrado");
    return;
  }

  const res = await fetch(APP_URL + 'upload-pacient', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: pacient_name,
      email: pacient_email
    })
  });

  await res.json();


  const modalEl = document.getElementById('courseModal');
  const modal = bootstrap.Modal.getInstance(modalEl);
  modal.hide();

  location.reload();

} catch (error) {
  console.error('Error en POST:', error);
}
}

addButton?.addEventListener("click", store);



function deleteData(id) {
  if (confirm("¿Seguro que quieres eliminar este paciente?")) {
    fetch(APP_URL + "pacients/" + id, {
      method: "DELETE"
    })
    .then(response => {
      if (!response.ok) throw new Error("Error al eliminar paciente");
      return response.json();
    })
    .then(data => {
      alert(data.mensaje);
      location.reload();
    })
    .catch(error => {
      console.error(error);
      alert("Hubo un problema al eliminar el paciente");
    });
  }
}


function updateData(id) {
  fetch(APP_URL + 'pacients/' + id)
    .then(res => {
      if (!res.ok) throw new Error('No se pudo obtener el paciente');
      return res.json();
    })
    .then(paciente => {
      document.getElementById('pacient_name').value = paciente.name;
      document.getElementById('pacient_email').value = paciente.email;

      document.getElementById('courseModalLabel').textContent = 'Editar paciente';

      const modalEl = document.getElementById('courseModal');
      const modal = new bootstrap.Modal(modalEl);
      modal.show();

      const addButton = document.getElementById('addButton');
      addButton.textContent = 'Actualizar';

      addButton.replaceWith(addButton.cloneNode(true));
      const newAddButton = document.getElementById('addButton');

      newAddButton.addEventListener('click', async () => {
        const name = document.getElementById('pacient_name').value.trim();
        const email = document.getElementById('pacient_email').value.trim();

        if (!name || !email) {
          alert('Todos los campos son obligatorios');
          return;
        }

        try {
          const res = await fetch(APP_URL + 'update-pacient/' + id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email })
          });

          if (!res.ok) throw new Error('Error al actualizar paciente');

          alert('Paciente actualizado correctamente');
          modal.hide();
          location.reload();
        } catch (error) {
          console.error(error);
          alert('Error al actualizar paciente');
        }
      });
    })
    .catch(err => {
      console.error(err);
      alert('No se pudo cargar el paciente para editar');
    });
}

