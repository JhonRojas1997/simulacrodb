const fs = require('fs');
const csv = require('csv-parser');
require('dotenv').config();
const mysql = require('mysql2/promise');

async function cargarpacientsDesdeCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const pacients = [];
    fs.createReadStream('pacients.csv')
      .pipe(csv())
      .on('data', (data) => {
        pacients.push(data);
      })
      .on('end', async () => {
        for (const pacient of pacients) {
          const query = `
            INSERT IGNORE INTO pacients(name, email) 
            VALUES (?, ?)
          `;
          const values = [pacient.name, pacient.email];
          await client.execute(query, values);
        }

        console.log('Pacientes cargados exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando pacientes:', err.message || err);
    if (client) await client.end();
  }
}



async function cargardoctorsDesdeCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const doctors = [];
    fs.createReadStream('doctors.csv')
      .pipe(csv())
      .on('data', (data) => {
        doctors.push(data);
      })
      .on('end', async () => {
        for (const doctor of doctors) {
          const query = `
            INSERT IGNORE INTO doctors(name) 
            VALUES (?)
          `;
          const values = [doctor.name];
          await client.execute(query, values);
        }

        console.log('doctores cargados exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando doctores:', err.message || err);
    if (client) await client.end();
  }
}




async function cargarlocationsDesdeCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const locations = [];
    fs.createReadStream('locations.csv')
      .pipe(csv())
      .on('data', (data) => {
        locations.push(data);
      })
      .on('end', async () => {
        for (const location of locations) {
          const query = `
            INSERT IGNORE INTO locations(name) 
            VALUES (?)
          `;
          const values = [location.name];
          await client.execute(query, values);
        }

        console.log('Sedes cargadas exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando sedes:', err.message || err);
    if (client) await client.end();
  }
}

async function cargarspecialitiesDesdeCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const specialities = [];
    fs.createReadStream('specialities.csv')
      .pipe(csv())
      .on('data', (data) => {
        specialities.push(data);
      })
      .on('end', async () => {
        for (const speciality of specialities) {
          const query = `
            INSERT IGNORE INTO specialities(name) 
            VALUES (?)
          `;
          const values = [speciality.name];
          await client.execute(query, values);
        }

        console.log('especialidades cargadas exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando especialidades:', err.message || err);
    if (client) await client.end();
  }
}

async function cargarappointmentsDesdeCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const appointments = [];
    fs.createReadStream('appointments.csv')
      .pipe(csv())
      .on('data', (data) => {
        appointments.push(data);
      })
      .on('end', async () => {
        for (const appointment of appointments) {
          const query = `
            INSERT IGNORE INTO appointments(date, hour , reason, observations, payment_method, status, id_pacient, id_doctor, id_speciality, id_location ) 
            VALUES (?,?,?,?,?,?,?,?,?,?)
          `;
          const values = [appointment.date, appointment.hour, appointment.reason, appointment.observations, appointment.payment_method, appointment.status, appointment.id_pacient, appointment.id_doctor, appointment.id_speciality, appointment.id_location];
          await client.execute(query, values);
        }

        console.log('citas cargadas exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando especialidades:', err.message || err);
    if (client) await client.end();
  }
}


module.exports = {
  cargarpacientsDesdeCSV,
  cargardoctorsDesdeCSV,
  cargarlocationsDesdeCSV,
  cargarspecialitiesDesdeCSV,
  cargarappointmentsDesdeCSV
};